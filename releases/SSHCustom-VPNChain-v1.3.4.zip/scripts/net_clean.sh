#!/system/bin/sh
#
# Belt-and-suspenders iptables cleanup. The Go daemon does its own cleanup
# in iptables.Cleanup() during shutdown, but if the daemon crashed or was
# killed mid-rule, leftover SSHC_* chains could remain and silently break
# the device's networking. This script is callable from sshcustom.sh stop
# and from customize.sh during a fresh install to guarantee a clean slate.
#
# Removes every SSHC_* chain name we have ever shipped (current and legacy)
# from the IPv4 nat + filter tables and the IPv6 nat + filter tables, plus
# the FORWARD ACCEPT rule that hotspot mode adds. Errors are silenced
# because every -D against a missing rule is harmless noise.

RUN_DIR="/data/adb/sshcustom-vpnchain/run"
LOG="$RUN_DIR/net_clean.log"
mkdir -p "$RUN_DIR"

IPT="iptables"
IP6T="ip6tables"
# Every chain SSHCustom-VPNChain has ever installed in the nat table.
# Keeping legacy names here means a user upgrading from a pre-v2 build
# still gets their orphaned chains removed.
NAT_CHAINS="SSHC_OUTPUT SSHC_PREROUTING SSHC_PROXY SSHC_DNS SSHC_HOTSPOT SSHC_HOTSPOT_DNS"
# Filter-table chains were introduced in v1.1.0 (leak protection).
FILTER_CHAINS="SSHC_FILTER_QUIC"
# IPv6 filter-table chains (also v1.1.0).
V6_FILTER_CHAINS="SSHC_FILTER_OUTPUT6 SSHC_FILTER_FORWARD6"
# Mangle-table chains for TPROXY mode (v1.2.0).
MANGLE_CHAINS="SSHC_TPROXY_OUT SSHC_TPROXY_PRE"
V6_MANGLE_CHAINS="SSHC_TPROXY_OUT6 SSHC_TPROXY_PRE6"
# TPROXY policy routing
TPROXY_MARK="0x1/0x1"
TPROXY_TABLE="100"
IFACES="wlan+ swlan+ ap+ rndis+ ncm+ bt-pan+"

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"; }
run() { "$@" >/dev/null 2>&1; }

clean_v4_nat() {
  for C in $NAT_CHAINS; do
    run $IPT -t nat -D OUTPUT -p tcp -j "$C"
    run $IPT -t nat -D OUTPUT -j "$C"
    run $IPT -t nat -D PREROUTING -p tcp -j "$C"
    run $IPT -t nat -D PREROUTING -j "$C"
    for IF in $IFACES; do
      run $IPT -t nat -D PREROUTING -i "$IF" -p tcp -j "$C"
      run $IPT -t nat -D PREROUTING -i "$IF" -j "$C"
    done
  done
  for C in $NAT_CHAINS; do
    run $IPT -t nat -F "$C"
    run $IPT -t nat -X "$C"
  done
  run $IPT -D FORWARD -j ACCEPT
}

clean_v4_filter() {
  for C in $FILTER_CHAINS; do
    run $IPT -t filter -D OUTPUT -p udp -j "$C"
    run $IPT -t filter -D OUTPUT -j "$C"
    run $IPT -t filter -F "$C"
    run $IPT -t filter -X "$C"
  done
}

clean_v6_nat() {
  for C in $NAT_CHAINS; do
    run $IP6T -t nat -D OUTPUT -p tcp -j "$C"
    run $IP6T -t nat -D OUTPUT -j "$C"
    run $IP6T -t nat -D PREROUTING -p tcp -j "$C"
    run $IP6T -t nat -D PREROUTING -j "$C"
    for IF in $IFACES; do
      run $IP6T -t nat -D PREROUTING -i "$IF" -p tcp -j "$C"
      run $IP6T -t nat -D PREROUTING -i "$IF" -j "$C"
    done
  done
  for C in $NAT_CHAINS; do
    run $IP6T -t nat -F "$C"
    run $IP6T -t nat -X "$C"
  done
}

clean_v6_filter() {
  for C in $V6_FILTER_CHAINS; do
    run $IP6T -t filter -D OUTPUT -j "$C"
    run $IP6T -t filter -D FORWARD -j "$C"
    run $IP6T -t filter -F "$C"
    run $IP6T -t filter -X "$C"
  done
}

clean_v4_mangle() {
  for C in $MANGLE_CHAINS; do
    run $IPT -t mangle -D OUTPUT -p tcp -j "$C"
    run $IPT -t mangle -D PREROUTING -p tcp -j "$C"
    for IF in $IFACES; do
      run $IPT -t mangle -D PREROUTING -i "$IF" -p tcp -j "$C"
    done
    run $IPT -t mangle -F "$C"
    run $IPT -t mangle -X "$C"
  done
}

clean_v6_mangle() {
  for C in $V6_MANGLE_CHAINS; do
    run $IP6T -t mangle -D OUTPUT -p tcp -j "$C"
    run $IP6T -t mangle -D PREROUTING -p tcp -j "$C"
    for IF in $IFACES; do
      run $IP6T -t mangle -D PREROUTING -i "$IF" -p tcp -j "$C"
    done
    run $IP6T -t mangle -F "$C"
    run $IP6T -t mangle -X "$C"
  done
  run $IP6T -D FORWARD -j ACCEPT
}

clean_policy_routes() {
  run ip rule del fwmark "$TPROXY_MARK" table "$TPROXY_TABLE"
  run ip route del local 0.0.0.0/0 dev lo table "$TPROXY_TABLE"
  run ip -6 rule del fwmark "$TPROXY_MARK" table "$TPROXY_TABLE"
  run ip -6 route del local ::/0 dev lo table "$TPROXY_TABLE"
  run ip route flush table "$TPROXY_TABLE"
  run ip -6 route flush table "$TPROXY_TABLE"
}

# Restore the kernel sysctls the daemon may have tweaked.
#
# We deliberately do NOT reset route_localnet=0 here. TPROXY requires
# route_localnet=1 to function (the policy route 'local 0.0.0.0/0 dev lo
# table 100' silently drops packets without it). In v1.3.3 this script
# unconditionally zeroed route_localnet, which combined with the daemon's
# similar bug to break TPROXY on the second apply cycle until reboot.
# Leaving route_localnet=1 has no security implications outside of routing
# packets bound to 127.0.0.0/8 — only privileged callers can craft those.
#
# rp_filter is the only knob we restore. Its strict (1) default is what
# Android ships with, and a defensive loose (2) value is only useful while
# our TPROXY rules are live.
restore_sysctls() {
  echo 1 > /proc/sys/net/ipv4/conf/all/rp_filter 2>/dev/null
  echo 1 > /proc/sys/net/ipv4/conf/default/rp_filter 2>/dev/null
}

log "clean start"
clean_v4_nat
clean_v4_filter
clean_v6_nat
clean_v6_filter
clean_v4_mangle
clean_v6_mangle
clean_policy_routes
restore_sysctls
log "clean complete"
exit 0
